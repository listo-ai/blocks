export declare const REMOTE_REACT_VERSION: string;
export default function Panel(): import("react/jsx-runtime").JSX.Element;
