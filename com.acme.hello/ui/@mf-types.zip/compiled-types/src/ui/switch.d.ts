import * as S from "@radix-ui/react-switch";
export declare const Switch: import("react").ForwardRefExoticComponent<Omit<S.SwitchProps & import("react").RefAttributes<HTMLButtonElement>, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
