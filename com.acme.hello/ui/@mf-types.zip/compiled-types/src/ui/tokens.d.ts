import type { CSSProperties } from "react";
export declare const tok: {
    primary: string;
    primaryFg: string;
    bg: string;
    fg: string;
    muted: string;
    mutedFg: string;
    border: string;
    accent: string;
    accentFg: string;
    destructive: string;
};
export declare const shadow: {
    sm: string;
    md: string;
    lg: string;
};
export declare function s(base: CSSProperties, ...extras: (CSSProperties | undefined | false)[]): CSSProperties;
