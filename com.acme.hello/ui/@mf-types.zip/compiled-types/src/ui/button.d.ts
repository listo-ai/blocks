import { type VariantProps } from "class-variance-authority";
import { type ButtonHTMLAttributes } from "react";
declare const variants: (props?: ({
    variant?: "default" | "secondary" | "outline" | "ghost" | "destructive" | null | undefined;
    size?: "icon" | "sm" | "md" | null | undefined;
} & import("class-variance-authority/types").ClassProp) | undefined) => string;
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof variants> {
    asChild?: boolean;
}
export declare const Button: import("react").ForwardRefExoticComponent<ButtonProps & import("react").RefAttributes<HTMLButtonElement>>;
export {};
