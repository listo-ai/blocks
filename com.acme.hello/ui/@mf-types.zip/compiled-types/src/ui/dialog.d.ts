import * as D from "@radix-ui/react-dialog";
import type { ReactNode } from "react";
export declare const Dialog: import("react").FC<D.DialogProps>;
export declare const DialogTrigger: import("react").ForwardRefExoticComponent<D.DialogTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;
export declare const DialogClose: import("react").ForwardRefExoticComponent<D.DialogCloseProps & import("react").RefAttributes<HTMLButtonElement>>;
export declare function DialogContent({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function DialogTitle({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function DialogDescription({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
